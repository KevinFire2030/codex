@echo off
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found.
  echo Install Python 3.10 or newer, then run this file again.
  pause
  exit /b 1
)

if not exist "recordings" mkdir "recordings"

python -c "import playwright" >nul 2>nul
if errorlevel 1 (
  echo Playwright is required for browser semantic recording.
  echo Run install_browser_dependencies.bat first, then run this file again.
  pause
  exit /b 1
)

set "RECORDER_ERROR_LOG=%TEMP%\work_recorder_error.log"
if exist "%RECORDER_ERROR_LOG%" del "%RECORDER_ERROR_LOG%" >nul 2>nul

python work_recorder.py record --out-dir "%~dp0recordings" --name work_recording --no-video --browser --no-browser-trace --start-url "about:blank" 2>"%RECORDER_ERROR_LOG%"
if errorlevel 1 (
  if exist "%RECORDER_ERROR_LOG%" type "%RECORDER_ERROR_LOG%"
)
pause
