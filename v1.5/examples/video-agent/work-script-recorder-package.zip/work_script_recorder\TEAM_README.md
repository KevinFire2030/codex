# 작업내용 스크립트 녹화 도구

브라우저와 Excel 같은 작업을 녹화해서, 이후 Codex가 같은 업무를 수행하는 자동화 에이전트나 Skill을 만들 수 있도록 증거 파일을 남기는 Windows용 도구입니다.

## 설치

1. ZIP 파일을 원하는 폴더에 압축 해제합니다.
2. `install_browser_dependencies.bat`를 한 번 실행합니다.
3. 설치가 끝나면 `start_recorder_portable.bat`를 실행합니다.

## 녹화 방법

1. `start_recorder_portable.bat`를 실행합니다.
2. 새 Playwright 브라우저 창이 열리면 그 창에서 웹 작업을 진행합니다.
3. Excel이나 기타 데스크톱 작업도 함께 하면 좌표/키보드/창 포커스 로그로 남습니다.
4. 작업이 끝나면 `Ctrl+Shift+F12`를 누릅니다.
5. 결과는 같은 폴더의 `recordings` 아래에 저장됩니다.

영상까지 필요하면 `start_recorder_with_video.bat`를 실행합니다.

기본 실행 배치 파일은 종료 안정성을 위해 Playwright `trace.zip` 생성을 끕니다. URL, selector, iframe, 다운로드, screenshot, 화면 영상은 그대로 저장됩니다.

## 결과 파일

- `session.md`: Codex 전달용 요약
- `action_script.md`: 사람이 읽기 쉬운 작업 절차
- `actions.jsonl`: 압축된 작업 타임라인
- `events.jsonl`: 원본 이벤트 로그
- `events.json`: 메타데이터 포함 전체 JSON
- `replay.py`: 좌표 기반 재현 스크립트
- `browser_summary.json`: URL 변화, 클릭 요소, 입력, 다운로드, screenshot 요약
- `browser_snapshot_latest.json`: 최신 iframe 구조와 버튼/link/input 목록
- `browser_snapshots\*.json`: 주기별 iframe/control inventory
- `screenshots\*.png`: 클릭/시작/종료 screenshot
- `downloads\*`: 브라우저 다운로드 이벤트로 저장된 파일
- `trace.zip`: `--no-browser-trace`를 빼고 직접 실행할 때 생성되는 Playwright trace
- `playwright_script.py`: selector 기반 Playwright 재현 초안

## Codex에게 요청할 문장

```text
이 녹화 폴더를 분석해서 같은 업무를 자동화하는 Codex Skill 또는 에이전트를 만들어줘.
action_script.md, actions.jsonl, events.jsonl, events.json, session.md,
browser_summary.json, browser_snapshot_latest.json, playwright_script.py를 근거로 작업 순서를 추출하고,
클릭 요소의 text/role/selector, URL 변화, iframe 구조, 버튼/link/input 목록, 다운로드 이벤트, screenshot을 함께 참고해줘.
좌표 재현이 아니라 사람이 이해할 수 있는 업무 절차와 Playwright/파일 처리 기반 자동화 구조로 정리해줘.
```

## 주의

- 비밀번호 필드는 마스킹하지만 일반 입력값은 저장됩니다.
- 고객정보, 개인정보, 영업비밀이 보이는 상태에서는 녹화하지 마세요.
- DOM/URL/iframe/download 같은 웹 의미 정보는 이 도구가 띄운 Playwright 브라우저 창에서만 기록됩니다.
- 최종 자동화는 좌표 재현보다 Playwright selector, Excel API, 파일 처리 스크립트 같은 의미 기반 방식으로 만드는 것이 좋습니다.
