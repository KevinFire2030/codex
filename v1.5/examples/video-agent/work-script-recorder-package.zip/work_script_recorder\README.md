# Work Script Recorder

Windows 작업을 녹화해서 Codex가 같은 업무 자동화 에이전트나 Skill을 만들 때 쓸 수 있는 증거 폴더를 생성합니다.

기존 좌표 기반 마우스/키보드/창 포커스 로그는 그대로 저장하고, `--browser` 모드에서는 Playwright가 띄운 브라우저 안에서 다음 의미 정보도 함께 저장합니다.

- 클릭한 요소의 `text`, `role`, `selector`
- URL 변화와 iframe 이동
- 페이지별 iframe 구조
- 버튼/link/input/textarea/select 목록
- 다운로드 이벤트와 저장 파일 정보
- 클릭/시작/종료 screenshot
- Playwright `trace.zip` 선택 생성
- 초안 재현 스크립트 `playwright_script.py`

## 처음 설치

브라우저 의미 녹화를 쓰려면 먼저 한 번 실행합니다.

```powershell
install_browser_dependencies.bat
```

이 배치 파일은 `requirements.txt` 패키지와 Playwright Chromium 브라우저를 설치합니다.

영상 파일까지 같이 녹화하려면 OpenCV/Pillow도 필요합니다. 위 설치 파일이 `requirements.txt` 전체를 설치하므로 별도 설치가 필요 없습니다.

## 빠른 실행

```powershell
start_recorder_portable.bat
```

실행하면 Playwright가 관리하는 새 브라우저 창이 열립니다. URL, selector, iframe, 다운로드, screenshot 같은 웹 의미 정보는 이 창 안에서 작업할 때만 기록됩니다.

기본 실행 배치 파일은 종료 안정성을 위해 Playwright `trace.zip` 생성을 끕니다. URL, selector, iframe, 다운로드, screenshot, 화면 영상은 그대로 저장됩니다.

작업이 끝나면 `Ctrl+Shift+F12`를 누르거나 콘솔에서 `Ctrl+C`를 누릅니다.

영상까지 남기려면 다음 파일을 실행합니다.

```powershell
start_recorder_with_video.bat
```

## 직접 실행 예시

```powershell
python work_recorder.py record --out-dir ".\recordings" --name monthly_report --browser --start-url "https://example.com"
```

브라우저 의미 기록 없이 기존 좌표/키보드 로그만 남기려면:

```powershell
python work_recorder.py record --out-dir ".\recordings" --name excel_task --no-browser --no-video
```

## 결과 파일

녹화가 끝나면 `recordings\날짜_시간_work_recording` 형식의 폴더가 생성됩니다.

- `session.md`: Codex에게 전달하기 좋은 요약
- `action_script.md`: 사람이 읽기 쉬운 작업 순서
- `actions.jsonl`: 에이전트/Skill 생성을 위한 압축 이벤트 로그
- `events.jsonl`: 원본 이벤트 로그
- `events.json`: 메타데이터와 이벤트를 합친 JSON
- `replay.py`: 같은 PC 배치에서 좌표 기반 재현을 시도하는 스크립트
- `browser_summary.json`: URL 변화, 클릭 요소, 입력, 다운로드, screenshot 요약
- `browser_snapshot_latest.json`: 최신 iframe 구조와 버튼/link/input 목록
- `browser_snapshots\*.json`: 주기별 iframe/control inventory
- `screenshots\*.png`: 시작/종료/클릭 screenshot
- `downloads\*`: 브라우저 다운로드 이벤트로 받은 파일
- `trace.zip`: `--no-browser-trace`를 빼고 직접 실행할 때 생성되는 Playwright trace
- `playwright_script.py`: 기록된 selector 기반 Playwright 재현 초안
- `screen.mp4` 또는 `screen.avi`: `--with-video` 사용 시 생성되는 화면 녹화

## Codex에게 요청할 문장

```text
이 녹화 폴더를 분석해서 같은 업무를 자동화하는 Codex Skill 또는 에이전트를 만들어줘.
action_script.md, actions.jsonl, events.jsonl, events.json, session.md,
browser_summary.json, browser_snapshot_latest.json, playwright_script.py를 근거로 작업 순서를 추출하고,
클릭 요소의 text/role/selector, URL 변화, iframe 구조, 버튼/link/input 목록, 다운로드 이벤트, screenshot을 함께 참고해줘.
좌표 재현이 아니라 사람이 이해할 수 있는 업무 절차와 Playwright/파일 처리 기반 자동화 구조로 정리해줘.
```

## 주의

- 비밀번호 필드는 마스킹하지만 일반 입력값은 기록됩니다. 고객정보, 개인정보, 영업비밀이 보이는 상태에서는 녹화하지 마세요.
- 브라우저 의미 정보는 이 도구가 띄운 Playwright 브라우저 창에서만 기록됩니다. 이미 열려 있던 Chrome/Edge 창의 DOM 정보는 읽지 못합니다.
- 좌표 기반 `replay.py`는 모니터 구성, 창 위치, 배율, 데이터 상태가 바뀌면 쉽게 깨집니다. 최종 자동화는 `playwright_script.py`와 JSON 증거를 참고해 selector/API 기반으로 다듬는 것이 좋습니다.
