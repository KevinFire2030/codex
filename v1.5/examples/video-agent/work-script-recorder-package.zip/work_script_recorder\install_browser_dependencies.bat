@echo off
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found.
  echo Install Python 3.10 or newer, then run this file again.
  pause
  exit /b 1
)

echo Installing Python packages from requirements.txt...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Failed to install Python packages.
  pause
  exit /b 1
)

echo Installing Playwright Chromium browser...
python -m playwright install chromium
if errorlevel 1 (
  echo Failed to install Playwright Chromium.
  pause
  exit /b 1
)

echo Done. You can now run start_recorder_portable.bat.
pause
