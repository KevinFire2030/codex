from __future__ import annotations

import argparse
import ctypes
import ctypes.wintypes as wintypes
import datetime as _dt
import json
import os
import queue
import signal
import re
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Any


IS_WINDOWS = os.name == "nt"

ImageGrab = None
cv2 = None
np = None

if IS_WINDOWS:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = ctypes.c_void_p
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    kernel32.CloseHandle.restype = wintypes.BOOL
    kernel32.QueryFullProcessImageNameW.argtypes = [
        wintypes.HANDLE,
        wintypes.DWORD,
        wintypes.LPWSTR,
        ctypes.POINTER(wintypes.DWORD),
    ]
    kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL

    user32.GetForegroundWindow.argtypes = []
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetClassNameW.restype = ctypes.c_int
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowThreadProcessId.restype = wintypes.DWORD
    user32.GetSystemMetrics.argtypes = [ctypes.c_int]
    user32.GetSystemMetrics.restype = ctypes.c_int
    user32.GetKeyNameTextW.argtypes = [wintypes.LONG, wintypes.LPWSTR, ctypes.c_int]
    user32.GetKeyNameTextW.restype = ctypes.c_int


DEFAULT_STOP_HOTKEY = "ctrl+shift+f12"
RECORD_SCHEMA_VERSION = 2
DEFAULT_BROWSER_START_URL = "about:blank"
MAX_TEXT_LENGTH = 500
MAX_INVENTORY_ITEMS = 300
BROWSER_SHUTDOWN_CHECK_SECONDS = 5.0
BROWSER_SHUTDOWN_MAX_SECONDS = 30.0


VK_NAMES: dict[str, int] = {
    "backspace": 0x08,
    "tab": 0x09,
    "enter": 0x0D,
    "shift": 0x10,
    "ctrl": 0x11,
    "control": 0x11,
    "alt": 0x12,
    "pause": 0x13,
    "capslock": 0x14,
    "esc": 0x1B,
    "escape": 0x1B,
    "space": 0x20,
    "pageup": 0x21,
    "pagedown": 0x22,
    "end": 0x23,
    "home": 0x24,
    "left": 0x25,
    "up": 0x26,
    "right": 0x27,
    "down": 0x28,
    "printscreen": 0x2C,
    "insert": 0x2D,
    "delete": 0x2E,
    "win": 0x5B,
    "lwin": 0x5B,
    "rwin": 0x5C,
}

for _i in range(1, 25):
    VK_NAMES[f"f{_i}"] = 0x70 + _i - 1
for _ch in "abcdefghijklmnopqrstuvwxyz":
    VK_NAMES[_ch] = ord(_ch.upper())
for _ch in "0123456789":
    VK_NAMES[_ch] = ord(_ch)


LEFT_RIGHT_EQUIVALENTS: dict[int, set[int]] = {
    0x10: {0x10, 0xA0, 0xA1},
    0x11: {0x11, 0xA2, 0xA3},
    0x12: {0x12, 0xA4, 0xA5},
}


def now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def parse_hotkey(text: str) -> set[int]:
    parts = [part.strip().lower() for part in text.split("+") if part.strip()]
    if not parts:
        raise ValueError("Hotkey cannot be empty.")
    missing = [part for part in parts if part not in VK_NAMES]
    if missing:
        raise ValueError(f"Unsupported hotkey key(s): {', '.join(missing)}")
    return {VK_NAMES[part] for part in parts}


def vk_matches(vk: int, expected: int) -> bool:
    return vk in LEFT_RIGHT_EQUIVALENTS.get(expected, {expected})


def is_hotkey_pressed(keys_down: set[int], hotkey: set[int]) -> bool:
    return all(any(vk_matches(actual, expected) for actual in keys_down) for expected in hotkey)


def ensure_windows() -> None:
    if not IS_WINDOWS:
        raise RuntimeError("This recorder currently supports Windows only.")


def terminate_child_processes(parent_pid: int) -> None:
    if not IS_WINDOWS:
        return
    script = r"""
$ParentPid = __PARENT_PID__
$all = Get-CimInstance Win32_Process
$ids = New-Object System.Collections.Generic.List[int]
function Add-Children([int]$TargetPid) {
  foreach ($child in $all | Where-Object { $_.ParentProcessId -eq $TargetPid }) {
    if (-not $ids.Contains([int]$child.ProcessId)) {
      $ids.Add([int]$child.ProcessId)
      Add-Children ([int]$child.ProcessId)
    }
  }
}
Add-Children $ParentPid
foreach ($id in $ids) {
  try { Stop-Process -Id $id -Force -ErrorAction Stop } catch {}
}
""".replace("__PARENT_PID__", str(int(parent_pid)))
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            check=False,
        )
    except Exception:
        pass


def load_video_dependencies() -> None:
    global ImageGrab, cv2, np
    if ImageGrab is not None and cv2 is not None and np is not None:
        return
    try:
        from PIL import ImageGrab as _ImageGrab
        import cv2 as _cv2
        import numpy as _np
    except ImportError as exc:  # pragma: no cover - shown to the user at runtime.
        print("Missing video dependency:", exc)
        print("Video recording needs: python -m pip install -r requirements.txt")
        raise
    ImageGrab = _ImageGrab
    cv2 = _cv2
    np = _np


def get_last_error_message() -> str:
    err = ctypes.get_last_error()
    if not err:
        return "unknown error"
    return ctypes.FormatError(err).strip()


def get_virtual_screen() -> dict[str, int]:
    ensure_windows()
    return {
        "x": int(user32.GetSystemMetrics(76)),  # SM_XVIRTUALSCREEN
        "y": int(user32.GetSystemMetrics(77)),  # SM_YVIRTUALSCREEN
        "width": int(user32.GetSystemMetrics(78)),  # SM_CXVIRTUALSCREEN
        "height": int(user32.GetSystemMetrics(79)),  # SM_CYVIRTUALSCREEN
    }


def get_foreground_window_info() -> dict[str, Any]:
    ensure_windows()
    hwnd = user32.GetForegroundWindow()
    if not hwnd:
        return {"hwnd": 0, "title": "", "class_name": "", "pid": 0, "process_path": ""}

    title_len = user32.GetWindowTextLengthW(hwnd)
    title_buf = ctypes.create_unicode_buffer(title_len + 1)
    user32.GetWindowTextW(hwnd, title_buf, len(title_buf))

    class_buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, class_buf, len(class_buf))

    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))

    process_path = ""
    if pid.value:
        process_path = query_process_path(pid.value)

    return {
        "hwnd": int(hwnd),
        "title": title_buf.value,
        "class_name": class_buf.value,
        "pid": int(pid.value),
        "process_path": process_path,
    }


def query_process_path(pid: int) -> str:
    ensure_windows()
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return ""
    try:
        size = wintypes.DWORD(32768)
        buf = ctypes.create_unicode_buffer(size.value)
        ok = kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size))
        return buf.value if ok else ""
    finally:
        kernel32.CloseHandle(handle)


class JsonlEventWriter(threading.Thread):
    def __init__(self, path: Path, events: "queue.Queue[dict[str, Any] | None]") -> None:
        super().__init__(daemon=True)
        self.path = path
        self.events = events
        self.count = 0
        self.error: str | None = None

    def run(self) -> None:
        try:
            with self.path.open("w", encoding="utf-8") as fp:
                while True:
                    item = self.events.get()
                    if item is None:
                        break
                    fp.write(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n")
                    self.count += 1
                    if self.count % 100 == 0:
                        fp.flush()
        except Exception:
            self.error = traceback.format_exc()


class WindowMonitor(threading.Thread):
    def __init__(
        self,
        stop_event: threading.Event,
        emit,
        started_at: float,
        interval: float = 0.35,
    ) -> None:
        super().__init__(daemon=True)
        self.stop_event = stop_event
        self.emit = emit
        self.started_at = started_at
        self.interval = interval
        self.last_signature: tuple[Any, ...] | None = None

    def run(self) -> None:
        while not self.stop_event.is_set():
            try:
                info = get_foreground_window_info()
                signature = (
                    info.get("hwnd"),
                    info.get("title"),
                    info.get("class_name"),
                    info.get("pid"),
                    info.get("process_path"),
                )
                if signature != self.last_signature:
                    self.last_signature = signature
                    self.emit(
                        {
                            "type": "window",
                            "action": "focus",
                            "t": round(time.perf_counter() - self.started_at, 6),
                            "wall_time": now_iso(),
                            **info,
                        }
                    )
            except Exception as exc:
                self.emit(
                    {
                        "type": "diagnostic",
                        "action": "window_monitor_error",
                        "t": round(time.perf_counter() - self.started_at, 6),
                        "message": str(exc),
                    }
                )
            self.stop_event.wait(self.interval)


class ScreenRecorder(threading.Thread):
    def __init__(
        self,
        stop_event: threading.Event,
        out_dir: Path,
        fps: float,
        emit,
        started_at: float,
    ) -> None:
        super().__init__(daemon=True)
        self.stop_event = stop_event
        self.out_dir = out_dir
        self.fps = fps
        self.emit = emit
        self.started_at = started_at
        self.video_path: Path | None = None
        self.frame_count = 0
        self.error: str | None = None

    def grab(self):
        load_video_dependencies()
        try:
            return ImageGrab.grab(all_screens=True)
        except TypeError:
            return ImageGrab.grab()

    def make_writer(self, width: int, height: int):
        load_video_dependencies()
        candidates = [
            ("screen.mp4", "mp4v"),
            ("screen.avi", "XVID"),
            ("screen.avi", "MJPG"),
        ]
        for filename, codec in candidates:
            path = self.out_dir / filename
            fourcc = cv2.VideoWriter_fourcc(*codec)
            writer = cv2.VideoWriter(str(path), fourcc, self.fps, (width, height))
            if writer.isOpened():
                self.video_path = path
                return writer
            writer.release()
        raise RuntimeError("Could not open OpenCV VideoWriter for mp4 or avi output.")

    def run(self) -> None:
        writer = None
        try:
            first = self.grab()
            frame = image_to_bgr(first)
            height, width = frame.shape[:2]
            width -= width % 2
            height -= height % 2
            frame = frame[:height, :width]

            writer = self.make_writer(width, height)
            self.emit(
                {
                    "type": "video",
                    "action": "started",
                    "t": round(time.perf_counter() - self.started_at, 6),
                    "path": self.video_path.name if self.video_path else "",
                    "width": width,
                    "height": height,
                    "fps": self.fps,
                }
            )

            next_frame = time.perf_counter()
            interval = 1.0 / self.fps
            while not self.stop_event.is_set():
                frame = image_to_bgr(self.grab())[:height, :width]
                writer.write(frame)
                self.frame_count += 1
                next_frame += interval
                delay = next_frame - time.perf_counter()
                if delay > 0:
                    self.stop_event.wait(delay)
                else:
                    next_frame = time.perf_counter()
        except Exception:
            self.error = traceback.format_exc()
            self.emit(
                {
                    "type": "diagnostic",
                    "action": "screen_recorder_error",
                    "t": round(time.perf_counter() - self.started_at, 6),
                    "message": self.error,
                }
            )
        finally:
            if writer is not None:
                writer.release()
            self.emit(
                {
                    "type": "video",
                    "action": "stopped",
                    "t": round(time.perf_counter() - self.started_at, 6),
                    "path": self.video_path.name if self.video_path else "",
                    "frames": self.frame_count,
                }
            )


def image_to_bgr(image):
    load_video_dependencies()
    arr = np.array(image)
    if arr.ndim == 2:
        return cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)
    if arr.shape[2] == 4:
        return cv2.cvtColor(arr, cv2.COLOR_RGBA2BGR)
    return cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)


BROWSER_EVENT_SCRIPT = r"""
(() => {
  if (window.__workRecorderInstalled) return;
  window.__workRecorderInstalled = true;

  const MAX_TEXT = 500;
  const interactiveSelector = [
    "button",
    "a[href]",
    "input",
    "textarea",
    "select",
    "[role='button']",
    "[role='link']",
    "[contenteditable='true']"
  ].join(",");

  function trimText(value) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, MAX_TEXT);
  }

  function cssEscape(value) {
    if (window.CSS && window.CSS.escape) return window.CSS.escape(String(value));
    return String(value).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }

  function attrEscape(value) {
    return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }

  function uniqueSelector(selector) {
    try {
      return document.querySelectorAll(selector).length === 1;
    } catch {
      return false;
    }
  }

  function normalizeElement(node) {
    if (!node) return null;
    let el = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
    if (!el) return null;
    if (el.closest) return el.closest(interactiveSelector) || el;
    return el;
  }

  function selectorFor(el) {
    if (!el || !el.tagName) return "";
    const tag = el.tagName.toLowerCase();
    if (el.id) {
      const selector = "#" + cssEscape(el.id);
      if (uniqueSelector(selector)) return selector;
    }
    const attrs = ["data-testid", "data-test", "aria-label", "name", "title", "placeholder"];
    for (const attr of attrs) {
      const value = el.getAttribute(attr);
      if (value) {
        const selector = `${tag}[${attr}="${attrEscape(value)}"]`;
        if (uniqueSelector(selector)) return selector;
      }
    }
    const text = trimText(el.innerText || el.textContent);
    if (text && ["button", "a"].includes(tag)) {
      const selector = `${tag}:has-text("${attrEscape(text.slice(0, 80))}")`;
      return selector;
    }
    const parts = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE && current !== document.documentElement) {
      const currentTag = current.tagName.toLowerCase();
      let nth = 1;
      let sibling = current.previousElementSibling;
      while (sibling) {
        if (sibling.tagName.toLowerCase() === currentTag) nth += 1;
        sibling = sibling.previousElementSibling;
      }
      parts.unshift(`${currentTag}:nth-of-type(${nth})`);
      const candidate = parts.join(" > ");
      if (uniqueSelector(candidate)) return candidate;
      current = current.parentElement;
    }
    return parts.join(" > ");
  }

  function roleFor(el) {
    if (!el || !el.tagName) return "";
    const explicit = el.getAttribute("role");
    if (explicit) return explicit;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (tag === "a" && el.href) return "link";
    if (tag === "button") return "button";
    if (tag === "textarea") return "textbox";
    if (tag === "select") return "combobox";
    if (tag === "input") {
      if (["button", "submit", "reset", "image"].includes(type)) return "button";
      if (["checkbox", "radio"].includes(type)) return type;
      if (["range"].includes(type)) return "slider";
      return "textbox";
    }
    if (el.isContentEditable) return "textbox";
    return "";
  }

  function valuePreview(el) {
    if (!el) return "";
    const tag = (el.tagName || "").toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (type === "password") return "[password masked]";
    if (tag === "input" || tag === "textarea" || tag === "select") {
      return trimText(el.value);
    }
    if (el.isContentEditable) return trimText(el.innerText || el.textContent);
    return "";
  }

  function elementInfo(el) {
    if (!el) return {};
    const tag = (el.tagName || "").toLowerCase();
    return {
      tag,
      role: roleFor(el),
      selector: selectorFor(el),
      text: trimText(el.innerText || el.textContent || el.value || el.getAttribute("aria-label")),
      aria_label: trimText(el.getAttribute("aria-label")),
      title: trimText(el.getAttribute("title")),
      name: el.getAttribute("name") || "",
      id: el.id || "",
      type: (el.getAttribute("type") || "").toLowerCase(),
      href: el.href || "",
      placeholder: el.getAttribute("placeholder") || "",
      value_preview: valuePreview(el),
      checked: Boolean(el.checked),
      disabled: Boolean(el.disabled)
    };
  }

  function emit(kind, domEvent) {
    const el = normalizeElement(domEvent.target);
    const payload = {
      kind,
      url: location.href,
      frame_url: location.href,
      x: Math.round(domEvent.clientX || 0),
      y: Math.round(domEvent.clientY || 0),
      button: domEvent.button,
      element: elementInfo(el)
    };
    if (typeof window.__workRecorderEmit === "function") {
      Promise.resolve(window.__workRecorderEmit(payload)).catch(() => {});
    }
  }

  document.addEventListener("click", event => emit("click", event), true);
  document.addEventListener("input", event => emit("input", event), true);
  document.addEventListener("change", event => emit("change", event), true);
})();
"""


BROWSER_INVENTORY_SCRIPT = r"""
(() => {
  const MAX_ITEMS = 300;
  const query = [
    "button",
    "a[href]",
    "input",
    "textarea",
    "select",
    "[role='button']",
    "[role='link']",
    "[contenteditable='true']"
  ].join(",");

  function trimText(value) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, 500);
  }

  function cssEscape(value) {
    if (window.CSS && window.CSS.escape) return window.CSS.escape(String(value));
    return String(value).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }

  function attrEscape(value) {
    return String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }

  function uniqueSelector(selector) {
    try {
      return document.querySelectorAll(selector).length === 1;
    } catch {
      return false;
    }
  }

  function selectorFor(el) {
    const tag = el.tagName.toLowerCase();
    if (el.id) {
      const selector = "#" + cssEscape(el.id);
      if (uniqueSelector(selector)) return selector;
    }
    for (const attr of ["data-testid", "data-test", "aria-label", "name", "title", "placeholder"]) {
      const value = el.getAttribute(attr);
      if (value) {
        const selector = `${tag}[${attr}="${attrEscape(value)}"]`;
        if (uniqueSelector(selector)) return selector;
      }
    }
    const parts = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE && current !== document.documentElement) {
      const currentTag = current.tagName.toLowerCase();
      let nth = 1;
      let sibling = current.previousElementSibling;
      while (sibling) {
        if (sibling.tagName.toLowerCase() === currentTag) nth += 1;
        sibling = sibling.previousElementSibling;
      }
      parts.unshift(`${currentTag}:nth-of-type(${nth})`);
      const candidate = parts.join(" > ");
      if (uniqueSelector(candidate)) return candidate;
      current = current.parentElement;
    }
    return parts.join(" > ");
  }

  function roleFor(el) {
    const explicit = el.getAttribute("role");
    if (explicit) return explicit;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (tag === "a" && el.href) return "link";
    if (tag === "button") return "button";
    if (tag === "textarea") return "textbox";
    if (tag === "select") return "combobox";
    if (tag === "input") {
      if (["button", "submit", "reset", "image"].includes(type)) return "button";
      if (["checkbox", "radio"].includes(type)) return type;
      if (type === "range") return "slider";
      return "textbox";
    }
    if (el.isContentEditable) return "textbox";
    return "";
  }

  function valuePreview(el) {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (type === "password") return "[password masked]";
    if (tag === "input" || tag === "textarea" || tag === "select") return trimText(el.value);
    if (el.isContentEditable) return trimText(el.innerText || el.textContent);
    return "";
  }

  return Array.from(document.querySelectorAll(query)).slice(0, MAX_ITEMS).map((el, index) => ({
    index,
    tag: el.tagName.toLowerCase(),
    role: roleFor(el),
    selector: selectorFor(el),
    text: trimText(el.innerText || el.textContent || el.value || el.getAttribute("aria-label")),
    aria_label: trimText(el.getAttribute("aria-label")),
    name: el.getAttribute("name") || "",
    id: el.id || "",
    type: (el.getAttribute("type") || "").toLowerCase(),
    href: el.href || "",
    placeholder: el.getAttribute("placeholder") || "",
    value_preview: valuePreview(el),
    checked: Boolean(el.checked),
    disabled: Boolean(el.disabled)
  }));
})();
"""


class BrowserSemanticRecorder(threading.Thread):
    def __init__(
        self,
        stop_event: threading.Event,
        session_dir: Path,
        emit,
        started_at: float,
        browser_name: str = "chromium",
        start_url: str = DEFAULT_BROWSER_START_URL,
        headless: bool = False,
        trace_enabled: bool = True,
        screenshots_enabled: bool = True,
        inventory_interval: float = 2.0,
    ) -> None:
        super().__init__(daemon=True)
        self.stop_event = stop_event
        self.session_dir = session_dir
        self.emit = emit
        self.started_at = started_at
        self.browser_name = browser_name
        self.start_url = start_url or DEFAULT_BROWSER_START_URL
        self.headless = headless
        self.trace_enabled = trace_enabled
        self.screenshots_enabled = screenshots_enabled
        self.inventory_interval = max(float(inventory_interval), 0.5)
        self.screenshots_dir = session_dir / "screenshots"
        self.snapshots_dir = session_dir / "browser_snapshots"
        self.downloads_dir = session_dir / "downloads"
        self.error: str | None = None
        self.trace_file: str | None = None
        self.page_ids: dict[int, int] = {}
        self.installed_page_ids: set[int] = set()
        self.last_urls: dict[int, str] = {}
        self.page_count = 0
        self.event_count = 0
        self.snapshot_count = 0
        self.screenshot_count = 0
        self.download_count = 0
        self._playwright = None
        self._browser = None
        self._context = None
        self._closing = False
        self.shutdown_timed_out = False
        self._context_page_handler = self._on_page
        self._page_event_handlers: dict[int, tuple[Any, Any, Any]] = {}

    def run(self) -> None:
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            self.error = (
                "Playwright is not installed. Run install_browser_dependencies.bat "
                "or: python -m pip install playwright && python -m playwright install chromium"
            )
            self.emit_browser("error", message=self.error, detail=str(exc))
            self.stop_event.set()
            return

        self.screenshots_dir.mkdir(exist_ok=True)
        self.snapshots_dir.mkdir(exist_ok=True)
        self.downloads_dir.mkdir(exist_ok=True)

        try:
            self._playwright = sync_playwright().start()
            browser_type = getattr(self._playwright, self.browser_name)
            self._browser = browser_type.launch(headless=self.headless)
            self._context = self._browser.new_context(accept_downloads=True)
            self._context.set_default_timeout(5000)
            self._context.on("page", self._context_page_handler)
            if self.trace_enabled:
                self._context.tracing.start(screenshots=True, snapshots=True, sources=True)

            page = self._context.new_page()
            self._on_page(page)
            self.emit_browser(
                "started",
                browser=self.browser_name,
                start_url=self.start_url,
                trace_enabled=self.trace_enabled,
                screenshots_enabled=self.screenshots_enabled,
            )
            if self.start_url and self.start_url != "about:blank":
                try:
                    page.goto(self.start_url, wait_until="domcontentloaded", timeout=20000)
                except Exception as exc:
                    self.emit_browser("navigation_error", url=self.start_url, message=str(exc))

            self._poll_pages()
            self._snapshot_all("started", include_screenshot=True)
            next_snapshot = time.perf_counter() + self.inventory_interval
            while not self.stop_event.is_set():
                self._poll_pages()
                if time.perf_counter() >= next_snapshot:
                    self._snapshot_all("interval")
                    next_snapshot = time.perf_counter() + self.inventory_interval
                self.stop_event.wait(0.2)

            self._snapshot_all("final", include_screenshot=False, collect_controls=False)
        except Exception:
            self.error = traceback.format_exc()
            self.emit_browser("error", message=self.error)
            self.stop_event.set()
        finally:
            self._close()

    def _close(self) -> None:
        self._closing = True
        try:
            self._detach_event_handlers()
            if self._context is not None and self.trace_enabled:
                trace_path = self.session_dir / "trace.zip"
                try:
                    self._context.tracing.stop(path=str(trace_path))
                    self.trace_file = trace_path.name
                    self.emit_browser("trace_saved", path=self.trace_file)
                except Exception as exc:
                    self.emit_browser("trace_error", message=str(exc))
            if self._context is not None:
                try:
                    self._context.close()
                except Exception as exc:
                    self.emit_browser("context_close_error", message=str(exc))
            if self._browser is not None:
                try:
                    self._browser.close()
                except Exception as exc:
                    self.emit_browser("browser_close_error", message=str(exc))
            if self._playwright is not None:
                try:
                    self._playwright.stop()
                except Exception as exc:
                    self.emit_browser("playwright_stop_error", message=str(exc))
        finally:
            self.emit_browser(
                "stopped",
                browser=self.browser_name,
                events=self.event_count,
                snapshots=self.snapshot_count,
                screenshots=self.screenshot_count,
                downloads=self.download_count,
                trace_file=self.trace_file,
            )

    def _detach_event_handlers(self) -> None:
        if self._context is not None:
            try:
                self._context.remove_listener("page", self._context_page_handler)
            except Exception:
                pass
        for page, frame_handler, download_handler in list(self._page_event_handlers.values()):
            try:
                page.remove_listener("framenavigated", frame_handler)
            except Exception:
                pass
            try:
                page.remove_listener("download", download_handler)
            except Exception:
                pass
        self._page_event_handlers.clear()

    def _on_page(self, page) -> None:
        if self._closing:
            return
        page_id = self._page_id(page)
        if id(page) in self.installed_page_ids:
            return
        self.installed_page_ids.add(id(page))
        self.last_urls[page_id] = page.url
        try:
            page.expose_binding("__workRecorderEmit", self._handle_dom_event)
        except Exception as exc:
            self.emit_browser("binding_error", page_id=page_id, message=str(exc))
        try:
            page.add_init_script(BROWSER_EVENT_SCRIPT)
            page.evaluate(BROWSER_EVENT_SCRIPT)
        except Exception as exc:
            self.emit_browser("inject_error", page_id=page_id, url=page.url, message=str(exc))
        frame_handler = lambda frame, page=page: self._handle_frame_navigated(page, frame)
        download_handler = lambda download, page=page: self._handle_download(page, download)
        page.on("framenavigated", frame_handler)
        page.on("download", download_handler)
        self._page_event_handlers[id(page)] = (page, frame_handler, download_handler)
        self.emit_browser("page_opened", page_id=page_id, url=page.url)

    def _page_id(self, page) -> int:
        key = id(page)
        if key not in self.page_ids:
            self.page_count += 1
            self.page_ids[key] = self.page_count
        return self.page_ids[key]

    def _poll_pages(self) -> None:
        if self._context is None or self._closing:
            return
        for page in list(self._context.pages):
            self._on_page(page)
            page_id = self._page_id(page)
            try:
                current_url = page.url
            except Exception:
                continue
            previous_url = self.last_urls.get(page_id)
            if current_url != previous_url:
                self.last_urls[page_id] = current_url
                self.emit_browser(
                    "url_changed",
                    page_id=page_id,
                    from_url=previous_url or "",
                    to_url=current_url,
                    title=self._safe_title(page),
                )

    def _handle_dom_event(self, source, payload: dict[str, Any]) -> None:
        if self._closing:
            return
        try:
            page = source.get("page")
            frame = source.get("frame")
            page_id = self._page_id(page)
            action = str(payload.get("kind") or "dom_event")
            element = payload.get("element") or {}
            event: dict[str, Any] = {
                "page_id": page_id,
                "url": getattr(page, "url", "") if page is not None else payload.get("url", ""),
                "frame_url": getattr(frame, "url", "") if frame is not None else payload.get("frame_url", ""),
                "x": payload.get("x"),
                "y": payload.get("y"),
                "button": payload.get("button"),
                "element": element,
                "element_text": element.get("text", ""),
                "element_role": element.get("role", ""),
                "selector": element.get("selector", ""),
            }
            if action == "click" and self.screenshots_enabled and page is not None:
                screenshot = self._take_page_screenshot(page, f"click_{self.event_count + 1:04d}")
                if screenshot:
                    event["screenshot"] = screenshot
            self.emit_browser(action, **event)
        except Exception as exc:
            self.emit_browser("dom_event_error", message=str(exc))

    def _handle_frame_navigated(self, page, frame) -> None:
        if self._closing:
            return
        try:
            page_id = self._page_id(page)
            is_main = frame == page.main_frame
            self.emit_browser(
                "frame_navigated",
                page_id=page_id,
                url=frame.url,
                frame_name=frame.name,
                is_main=is_main,
                title=self._safe_title(page) if is_main else "",
            )
            if is_main:
                previous = self.last_urls.get(page_id, "")
                self.last_urls[page_id] = frame.url
                if frame.url != previous:
                    self.emit_browser(
                        "url_changed",
                        page_id=page_id,
                        from_url=previous,
                        to_url=frame.url,
                        title=self._safe_title(page),
                    )
        except Exception as exc:
            self.emit_browser("frame_event_error", message=str(exc))

    def _handle_download(self, page, download) -> None:
        if self._closing:
            return
        page_id = self._page_id(page)
        suggested = download.suggested_filename or "download"
        target = unique_artifact_path(self.downloads_dir, suggested)
        event: dict[str, Any] = {
            "page_id": page_id,
            "url": getattr(page, "url", ""),
            "download_url": download.url,
            "suggested_filename": suggested,
            "path": relative_artifact_path(self.session_dir, target),
        }
        try:
            download.save_as(str(target))
            failure = download.failure()
            event["failure"] = failure or ""
            event["size_bytes"] = target.stat().st_size if target.exists() else 0
        except Exception as exc:
            event["failure"] = str(exc)
        self.download_count += 1
        self.emit_browser("download", **event)

    def _snapshot_all(self, reason: str, include_screenshot: bool = False, collect_controls: bool = True) -> None:
        if self._context is None:
            return
        self.snapshot_count += 1
        snapshot: dict[str, Any] = {
            "created_at": now_iso(),
            "reason": reason,
            "pages": [],
        }
        for page in list(self._context.pages):
            page_id = self._page_id(page)
            page_data: dict[str, Any] = {
                "page_id": page_id,
                "url": "",
                "title": "",
                "iframes": {},
                "controls": [],
                "screenshot": "",
            }
            try:
                page_data["url"] = page.url
                page_data["title"] = self._safe_title(page)
                page_data["iframes"] = self._frame_tree(page.main_frame)
                if collect_controls:
                    page_data["controls"] = self._collect_controls(page)
                else:
                    page_data["controls"] = []
                    page_data["note"] = "Final snapshot skips control inventory so recorder shutdown stays fast."
                if include_screenshot and self.screenshots_enabled:
                    page_data["screenshot"] = self._take_page_screenshot(page, f"{reason}_{page_id:02d}")
            except Exception as exc:
                page_data["error"] = str(exc)
            snapshot["pages"].append(page_data)

        path = self.snapshots_dir / f"snapshot_{self.snapshot_count:04d}_{safe_filename(reason)}.json"
        write_json(path, snapshot)
        write_json(self.session_dir / "browser_snapshot_latest.json", snapshot)
        self.emit_browser(
            "snapshot",
            reason=reason,
            path=relative_artifact_path(self.session_dir, path),
            page_count=len(snapshot["pages"]),
            control_count=sum(len(page.get("controls", [])) for page in snapshot["pages"]),
        )

    def _collect_controls(self, page) -> list[dict[str, Any]]:
        controls: list[dict[str, Any]] = []
        for frame_index, frame in enumerate(list(page.frames)):
            if len(controls) >= MAX_INVENTORY_ITEMS:
                break
            try:
                rows = frame.evaluate(BROWSER_INVENTORY_SCRIPT)
            except Exception as exc:
                controls.append(
                    {
                        "frame_index": frame_index,
                        "frame_name": frame.name,
                        "frame_url": frame.url,
                        "error": str(exc),
                    }
                )
                continue
            for row in rows or []:
                row["frame_index"] = frame_index
                row["frame_name"] = frame.name
                row["frame_url"] = frame.url
                controls.append(row)
                if len(controls) >= MAX_INVENTORY_ITEMS:
                    break
        return controls

    def _frame_tree(self, frame) -> dict[str, Any]:
        children = []
        for child in list(frame.child_frames):
            try:
                children.append(self._frame_tree(child))
            except Exception as exc:
                children.append({"error": str(exc)})
        return {
            "name": frame.name,
            "url": frame.url,
            "child_count": len(children),
            "children": children,
        }

    def _take_page_screenshot(self, page, label: str) -> str:
        try:
            self.screenshot_count += 1
            filename = f"{self.screenshot_count:04d}_{safe_filename(label)}.png"
            path = self.screenshots_dir / filename
            page.screenshot(path=str(path), full_page=False)
            return relative_artifact_path(self.session_dir, path)
        except Exception as exc:
            self.emit_browser("screenshot_error", label=label, message=str(exc))
            return ""

    def _safe_title(self, page) -> str:
        try:
            return page.title()
        except Exception:
            return ""

    def emit_browser(self, action: str, **payload: Any) -> None:
        self.event_count += 1
        self.emit(
            {
                "type": "browser",
                "action": action,
                "t": round(time.perf_counter() - self.started_at, 6),
                "wall_time": now_iso(),
                **payload,
            }
        )


class POINT(ctypes.Structure):
    _fields_ = [("x", wintypes.LONG), ("y", wintypes.LONG)]


class MSLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("pt", POINT),
        ("mouseData", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_void_p),
    ]


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_void_p),
    ]


HOOKPROC = ctypes.WINFUNCTYPE(wintypes.LPARAM, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)

if IS_WINDOWS:
    user32.SetWindowsHookExW.argtypes = [
        ctypes.c_int,
        HOOKPROC,
        ctypes.c_void_p,
        wintypes.DWORD,
    ]
    user32.SetWindowsHookExW.restype = ctypes.c_void_p
    user32.UnhookWindowsHookEx.argtypes = [ctypes.c_void_p]
    user32.UnhookWindowsHookEx.restype = wintypes.BOOL
    user32.CallNextHookEx.argtypes = [
        ctypes.c_void_p,
        ctypes.c_int,
        wintypes.WPARAM,
        wintypes.LPARAM,
    ]
    user32.CallNextHookEx.restype = wintypes.LPARAM
    user32.PeekMessageW.argtypes = [
        ctypes.POINTER(wintypes.MSG),
        wintypes.HWND,
        wintypes.UINT,
        wintypes.UINT,
        wintypes.UINT,
    ]
    user32.PeekMessageW.restype = wintypes.BOOL
    user32.TranslateMessage.argtypes = [ctypes.POINTER(wintypes.MSG)]
    user32.TranslateMessage.restype = wintypes.BOOL
    user32.DispatchMessageW.argtypes = [ctypes.POINTER(wintypes.MSG)]
    user32.DispatchMessageW.restype = wintypes.LPARAM


class InputHookRecorder(threading.Thread):
    WH_KEYBOARD_LL = 13
    WH_MOUSE_LL = 14
    HC_ACTION = 0

    WM_KEYDOWN = 0x0100
    WM_KEYUP = 0x0101
    WM_SYSKEYDOWN = 0x0104
    WM_SYSKEYUP = 0x0105

    WM_MOUSEMOVE = 0x0200
    WM_LBUTTONDOWN = 0x0201
    WM_LBUTTONUP = 0x0202
    WM_RBUTTONDOWN = 0x0204
    WM_RBUTTONUP = 0x0205
    WM_MBUTTONDOWN = 0x0207
    WM_MBUTTONUP = 0x0208
    WM_MOUSEWHEEL = 0x020A
    WM_XBUTTONDOWN = 0x020B
    WM_XBUTTONUP = 0x020C
    WM_MOUSEHWHEEL = 0x020E

    PM_REMOVE = 0x0001

    def __init__(
        self,
        stop_event: threading.Event,
        emit,
        started_at: float,
        stop_hotkey: set[int],
        move_sample_ms: int = 60,
    ) -> None:
        super().__init__(daemon=True)
        self.stop_event = stop_event
        self.emit = emit
        self.started_at = started_at
        self.stop_hotkey = stop_hotkey
        self.move_sample = max(move_sample_ms, 10) / 1000.0
        self.mouse_hook = None
        self.keyboard_hook = None
        self.mouse_proc = HOOKPROC(self._mouse_callback)
        self.keyboard_proc = HOOKPROC(self._keyboard_callback)
        self.keys_down: set[int] = set()
        self.buttons_down: set[str] = set()
        self.last_move_t = 0.0
        self.ready = threading.Event()
        self.error: str | None = None

    def run(self) -> None:
        ensure_windows()
        try:
            hmod = kernel32.GetModuleHandleW(None)
            self.mouse_hook = user32.SetWindowsHookExW(
                self.WH_MOUSE_LL, self.mouse_proc, hmod, 0
            )
            if not self.mouse_hook:
                raise RuntimeError("Mouse hook failed: " + get_last_error_message())
            self.keyboard_hook = user32.SetWindowsHookExW(
                self.WH_KEYBOARD_LL, self.keyboard_proc, hmod, 0
            )
            if not self.keyboard_hook:
                raise RuntimeError("Keyboard hook failed: " + get_last_error_message())

            self.ready.set()
            msg = wintypes.MSG()
            while not self.stop_event.is_set():
                while user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, self.PM_REMOVE):
                    user32.TranslateMessage(ctypes.byref(msg))
                    user32.DispatchMessageW(ctypes.byref(msg))
                self.stop_event.wait(0.01)
        except Exception:
            self.error = traceback.format_exc()
            self.emit(
                {
                    "type": "diagnostic",
                    "action": "input_hook_error",
                    "t": round(time.perf_counter() - self.started_at, 6),
                    "message": self.error,
                }
            )
            self.ready.set()
            self.stop_event.set()
        finally:
            if self.keyboard_hook:
                user32.UnhookWindowsHookEx(self.keyboard_hook)
            if self.mouse_hook:
                user32.UnhookWindowsHookEx(self.mouse_hook)

    def _base_event(self, event_type: str, action: str) -> dict[str, Any]:
        return {
            "type": event_type,
            "action": action,
            "t": round(time.perf_counter() - self.started_at, 6),
        }

    def _keyboard_callback(self, n_code, w_param, l_param):
        if n_code == self.HC_ACTION:
            kb = ctypes.cast(l_param, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
            vk = int(kb.vkCode)
            action = None
            if w_param in (self.WM_KEYDOWN, self.WM_SYSKEYDOWN):
                action = "key_down"
                self.keys_down.add(vk)
            elif w_param in (self.WM_KEYUP, self.WM_SYSKEYUP):
                action = "key_up"
                self.keys_down.discard(vk)

            if action:
                is_stop = is_hotkey_pressed(self.keys_down | {vk}, self.stop_hotkey)
                if is_stop and action == "key_down":
                    held_keys = sorted(self.keys_down | {vk})
                    self.emit(
                        {
                            **self._base_event("control", "stop_hotkey"),
                            "hotkey": hotkey_to_text(self.stop_hotkey),
                        }
                    )
                    for held_vk in held_keys:
                        self.emit(
                            {
                                **self._base_event("keyboard", "key_up"),
                                "vk": held_vk,
                                "scan_code": 0,
                                "flags": 0,
                                "key": f"VK_{held_vk}",
                                "synthetic": True,
                            }
                        )
                    self.keys_down.clear()
                    self.stop_event.set()
                    return 1

                self.emit(
                    {
                        **self._base_event("keyboard", action),
                        "vk": vk,
                        "scan_code": int(kb.scanCode),
                        "flags": int(kb.flags),
                        "key": get_key_name(vk, int(kb.scanCode), int(kb.flags)),
                    }
                )

        return user32.CallNextHookEx(self.keyboard_hook, n_code, w_param, l_param)

    def _mouse_callback(self, n_code, w_param, l_param):
        if n_code == self.HC_ACTION:
            ms = ctypes.cast(l_param, ctypes.POINTER(MSLLHOOKSTRUCT)).contents
            action, button, wheel_delta = mouse_message_to_action(int(w_param), int(ms.mouseData))
            if action:
                now = time.perf_counter()
                if action == "move":
                    if self.buttons_down:
                        sample = min(self.move_sample, 0.025)
                    else:
                        sample = self.move_sample
                    if now - self.last_move_t < sample:
                        return user32.CallNextHookEx(self.mouse_hook, n_code, w_param, l_param)
                    self.last_move_t = now
                elif action.endswith("_down") and button:
                    self.buttons_down.add(button)
                elif action.endswith("_up") and button:
                    self.buttons_down.discard(button)

                event = {
                    **self._base_event("mouse", action),
                    "x": int(ms.pt.x),
                    "y": int(ms.pt.y),
                }
                if button:
                    event["button"] = button
                if wheel_delta is not None:
                    event["wheel_delta"] = wheel_delta
                self.emit(event)

        return user32.CallNextHookEx(self.mouse_hook, n_code, w_param, l_param)


def hotkey_to_text(vks: set[int]) -> str:
    reverse = {value: key for key, value in VK_NAMES.items()}
    preferred = {0x10: "shift", 0x11: "ctrl", 0x12: "alt"}
    return "+".join(preferred.get(vk, reverse.get(vk, f"vk{vk}")) for vk in sorted(vks))


def get_key_name(vk: int, scan_code: int, flags: int) -> str:
    if not IS_WINDOWS:
        return f"VK_{vk}"
    extended = 1 if flags & 0x01 else 0
    lparam = (scan_code << 16) | (extended << 24)
    buf = ctypes.create_unicode_buffer(128)
    if user32.GetKeyNameTextW(lparam, buf, len(buf)):
        return buf.value
    if 0x30 <= vk <= 0x39 or 0x41 <= vk <= 0x5A:
        return chr(vk)
    return f"VK_{vk}"


def mouse_message_to_action(message: int, mouse_data: int):
    mapping = {
        InputHookRecorder.WM_MOUSEMOVE: ("move", None, None),
        InputHookRecorder.WM_LBUTTONDOWN: ("button_down", "left", None),
        InputHookRecorder.WM_LBUTTONUP: ("button_up", "left", None),
        InputHookRecorder.WM_RBUTTONDOWN: ("button_down", "right", None),
        InputHookRecorder.WM_RBUTTONUP: ("button_up", "right", None),
        InputHookRecorder.WM_MBUTTONDOWN: ("button_down", "middle", None),
        InputHookRecorder.WM_MBUTTONUP: ("button_up", "middle", None),
    }
    if message in mapping:
        return mapping[message]
    if message == InputHookRecorder.WM_MOUSEWHEEL:
        return "wheel", None, signed_hiword(mouse_data)
    if message == InputHookRecorder.WM_MOUSEHWHEEL:
        return "hwheel", None, signed_hiword(mouse_data)
    if message == InputHookRecorder.WM_XBUTTONDOWN:
        return "button_down", f"x{mouse_data >> 16}", None
    if message == InputHookRecorder.WM_XBUTTONUP:
        return "button_up", f"x{mouse_data >> 16}", None
    return None, None, None


def signed_hiword(value: int) -> int:
    hi = (value >> 16) & 0xFFFF
    return hi - 0x10000 if hi & 0x8000 else hi


def create_session_dir(base_dir: Path, name: str | None) -> Path:
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    suffix = slugify(name or "work_recording")
    session = base_dir / f"{stamp}_{suffix}"
    session.mkdir(parents=True, exist_ok=False)
    return session


def slugify(text: str) -> str:
    cleaned = []
    for char in text.strip().replace(" ", "_"):
        if char.isalnum() or char in ("_", "-", "."):
            cleaned.append(char)
    return "".join(cleaned).strip("._-") or "work_recording"


def safe_filename(text: str, fallback: str = "artifact") -> str:
    text = re.sub(r"[^\w.\-가-힣]+", "_", str(text), flags=re.UNICODE).strip("._-")
    return (text[:120] or fallback).strip("._-") or fallback


def unique_artifact_path(directory: Path, filename: str) -> Path:
    safe = safe_filename(Path(filename).name, "download")
    candidate = directory / safe
    if not candidate.exists():
        return candidate
    stem = candidate.stem or "download"
    suffix = candidate.suffix
    for idx in range(2, 10000):
        candidate = directory / f"{stem}_{idx}{suffix}"
        if not candidate.exists():
            return candidate
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    return directory / f"{stem}_{stamp}{suffix}"


def relative_artifact_path(base_dir: Path, path: Path) -> str:
    try:
        return str(path.relative_to(base_dir)).replace("\\", "/")
    except ValueError:
        return str(path)


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    events = []
    with path.open("r", encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if line:
                events.append(json.loads(line))
    return events


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as fp:
        for row in rows:
            fp.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def summarize_events(events: list[dict[str, Any]]) -> dict[str, Any]:
    counts: dict[str, int] = {}
    windows: list[dict[str, Any]] = []
    urls: list[dict[str, Any]] = []
    downloads: list[dict[str, Any]] = []
    screenshots: list[str] = []
    seen_windows: set[tuple[str, str]] = set()
    seen_urls: set[str] = set()
    last_t = 0.0
    for event in events:
        counts[event.get("type", "unknown")] = counts.get(event.get("type", "unknown"), 0) + 1
        last_t = max(last_t, float(event.get("t", 0.0)))
        if event.get("type") == "window":
            sig = (event.get("title", ""), event.get("process_path", ""))
            if sig not in seen_windows:
                seen_windows.add(sig)
                windows.append(
                    {
                        "t": event.get("t"),
                        "title": event.get("title"),
                        "class_name": event.get("class_name"),
                        "process_path": event.get("process_path"),
                    }
                )
        elif event.get("type") == "browser":
            action = event.get("action")
            url = event.get("to_url") or event.get("url")
            if action in {"started", "url_changed", "frame_navigated", "click", "input", "change"} and url:
                if url not in seen_urls:
                    seen_urls.add(url)
                    urls.append(
                        {
                            "t": event.get("t"),
                            "action": action,
                            "url": url,
                            "title": event.get("title", ""),
                        }
                    )
            if action == "download":
                downloads.append(
                    {
                        "t": event.get("t"),
                        "url": event.get("download_url"),
                        "suggested_filename": event.get("suggested_filename"),
                        "path": event.get("path"),
                        "failure": event.get("failure"),
                    }
                )
            screenshot = event.get("screenshot")
            if screenshot:
                screenshots.append(str(screenshot))
    return {
        "duration_seconds": round(last_t, 3),
        "event_counts": counts,
        "windows": windows[:50],
        "window_count": len(windows),
        "urls": urls[:100],
        "url_count": len(urls),
        "downloads": downloads,
        "download_count": len(downloads),
        "screenshots": screenshots[:200],
        "screenshot_count": len(screenshots),
    }


def build_action_timeline(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    keyboard_buffer: dict[str, Any] | None = None

    def flush_keyboard() -> None:
        nonlocal keyboard_buffer
        if not keyboard_buffer:
            return
        keys = keyboard_buffer["keys"]
        actions.append(
            {
                "action": "keyboard_sequence",
                "t_start": round(float(keyboard_buffer["t_start"]), 6),
                "t_end": round(float(keyboard_buffer["t_end"]), 6),
                "key_count": len(keys),
                "keys": keys,
                "approx_text": keys_to_approx_text(keys),
            }
        )
        keyboard_buffer = None

    for event in events:
        event_type = event.get("type")
        event_action = event.get("action")
        event_t = float(event.get("t", 0.0))

        if event_type == "keyboard":
            if event_action == "key_down" and not event.get("synthetic"):
                key = str(event.get("key") or f"VK_{event.get('vk')}")
                if keyboard_buffer and event_t - float(keyboard_buffer["t_end"]) > 1.4:
                    flush_keyboard()
                if not keyboard_buffer:
                    keyboard_buffer = {"t_start": event_t, "t_end": event_t, "keys": []}
                keyboard_buffer["t_end"] = event_t
                keyboard_buffer["keys"].append(key)
            continue

        if event_type == "mouse" and event_action == "move":
            continue

        flush_keyboard()

        if event_type == "window":
            actions.append(
                {
                    "action": "window_focus",
                    "t": event_t,
                    "title": event.get("title", ""),
                    "class_name": event.get("class_name", ""),
                    "process_path": event.get("process_path", ""),
                }
            )
        elif event_type == "browser":
            element = event.get("element") or {}
            item = {
                "action": f"browser_{event_action}",
                "t": event_t,
                "page_id": event.get("page_id"),
                "url": event.get("url") or event.get("to_url") or event.get("download_url") or "",
                "frame_url": event.get("frame_url", ""),
                "selector": event.get("selector") or element.get("selector", ""),
                "element_text": event.get("element_text") or element.get("text", ""),
                "element_role": event.get("element_role") or element.get("role", ""),
            }
            for key in (
                "from_url",
                "to_url",
                "download_url",
                "suggested_filename",
                "path",
                "screenshot",
                "failure",
                "reason",
                "control_count",
                "is_main",
            ):
                if key in event:
                    item[key] = event[key]
            if event_action in {"input", "change"}:
                item["value_preview"] = element.get("value_preview", "")
                item["input_type"] = element.get("type", "")
            actions.append(item)
        elif event_type == "mouse":
            item = {
                "action": "mouse_event",
                "mouse_action": event_action,
                "t": event_t,
                "x": event.get("x"),
                "y": event.get("y"),
            }
            if "button" in event:
                item["button"] = event["button"]
            if "wheel_delta" in event:
                item["wheel_delta"] = event["wheel_delta"]
            actions.append(item)
        elif event_type == "control":
            actions.append({"action": "control", "control_action": event_action, "t": event_t})
        elif event_type == "session":
            actions.append(
                {
                    "action": "session",
                    "session_action": event_action,
                    "t": event_t,
                    "wall_time": event.get("wall_time"),
                }
            )

    flush_keyboard()
    return actions


def keys_to_approx_text(keys: list[str]) -> str:
    special = {
        "Space": " ",
        "Enter": "[Enter]",
        "Tab": "[Tab]",
        "Backspace": "[Backspace]",
        "Delete": "[Delete]",
        "Esc": "[Esc]",
        "Escape": "[Esc]",
    }
    modifiers = {"Shift", "Ctrl", "Control", "Alt", "Windows", "Left Windows", "Right Windows"}
    parts: list[str] = []
    for key in keys:
        if key in modifiers:
            continue
        if key in special:
            parts.append(special[key])
        elif len(key) == 1:
            parts.append(key)
        else:
            parts.append(f"[{key}]")
    return "".join(parts) or "[modifier keys only]"


def write_action_files(session_dir: Path, actions: list[dict[str, Any]]) -> None:
    write_jsonl(session_dir / "actions.jsonl", actions)
    lines = [
        "# Action Script",
        "",
        "This file is a condensed script for Codex agent or skill generation.",
        "It removes high-volume mouse-move events and keeps focused windows, browser semantic events, clicks, wheel events, and keyboard bursts.",
        "",
        "| Time | Action | Details |",
        "| ---: | --- | --- |",
    ]
    for item in actions:
        lines.append(
            f"| {format_action_time(item)} | {escape_md(str(item.get('action', '')))} | {escape_md(action_details(item))} |"
        )
    lines.append("")
    (session_dir / "action_script.md").write_text("\n".join(lines), encoding="utf-8")


def format_action_time(item: dict[str, Any]) -> str:
    if "t_start" in item and "t_end" in item:
        return f"{item['t_start']} - {item['t_end']}"
    return str(item.get("t", ""))


def action_details(item: dict[str, Any]) -> str:
    action = item.get("action")
    if action == "window_focus":
        title = truncate(str(item.get("title") or ""), 90)
        process = Path(str(item.get("process_path") or "")).name
        return f"title={title}; process={process}"
    if str(action).startswith("browser_"):
        if action == "browser_click":
            text = truncate(str(item.get("element_text") or ""), 80)
            return (
                f"click role={item.get('element_role')}; selector={item.get('selector')}; "
                f"text={text}; url={truncate(str(item.get('url') or ''), 90)}"
            )
        if action in {"browser_input", "browser_change"}:
            value = truncate(str(item.get("value_preview") or ""), 80)
            return (
                f"{action.replace('browser_', '')} selector={item.get('selector')}; "
                f"type={item.get('input_type')}; value={value}"
            )
        if action == "browser_url_changed":
            return (
                f"from={truncate(str(item.get('from_url') or ''), 80)}; "
                f"to={truncate(str(item.get('to_url') or item.get('url') or ''), 100)}"
            )
        if action == "browser_frame_navigated":
            return f"frame_url={truncate(str(item.get('url') or ''), 120)}; is_main={item.get('is_main')}"
        if action == "browser_download":
            return (
                f"filename={item.get('suggested_filename')}; path={item.get('path')}; "
                f"url={truncate(str(item.get('download_url') or ''), 90)}"
            )
        if action == "browser_snapshot":
            return f"reason={item.get('reason')}; controls={item.get('control_count')}; path={item.get('path')}"
        return truncate(json.dumps(item, ensure_ascii=False), 180)
    if action == "mouse_event":
        details = f"{item.get('mouse_action')} at ({item.get('x')}, {item.get('y')})"
        if item.get("button"):
            details += f"; button={item.get('button')}"
        if item.get("wheel_delta") is not None:
            details += f"; wheel_delta={item.get('wheel_delta')}"
        return details
    if action == "keyboard_sequence":
        approx = truncate(str(item.get("approx_text") or ""), 120)
        return f"{item.get('key_count')} key_down events; approx_text={approx}"
    if action == "session":
        return str(item.get("session_action", ""))
    if action == "control":
        return str(item.get("control_action", ""))
    return truncate(json.dumps(item, ensure_ascii=False), 160)


def write_browser_artifacts(session_dir: Path, events: list[dict[str, Any]]) -> dict[str, str]:
    browser_events = [event for event in events if event.get("type") == "browser"]
    if not browser_events:
        return {}

    url_history = []
    clicked_elements = []
    inputs = []
    downloads = []
    screenshots = []
    snapshots = []
    for event in browser_events:
        action = event.get("action")
        if action in {"url_changed", "frame_navigated"}:
            url_history.append(
                {
                    "t": event.get("t"),
                    "action": action,
                    "from_url": event.get("from_url", ""),
                    "to_url": event.get("to_url") or event.get("url", ""),
                    "is_main": event.get("is_main", ""),
                    "title": event.get("title", ""),
                }
            )
        elif action == "click":
            clicked_elements.append(
                {
                    "t": event.get("t"),
                    "url": event.get("url"),
                    "frame_url": event.get("frame_url"),
                    "text": event.get("element_text"),
                    "role": event.get("element_role"),
                    "selector": event.get("selector"),
                    "screenshot": event.get("screenshot", ""),
                }
            )
        elif action in {"input", "change"}:
            element = event.get("element") or {}
            inputs.append(
                {
                    "t": event.get("t"),
                    "url": event.get("url"),
                    "frame_url": event.get("frame_url"),
                    "selector": event.get("selector"),
                    "role": event.get("element_role"),
                    "type": element.get("type", ""),
                    "value_preview": element.get("value_preview", ""),
                }
            )
        elif action == "download":
            downloads.append(
                {
                    "t": event.get("t"),
                    "page_url": event.get("url"),
                    "download_url": event.get("download_url"),
                    "suggested_filename": event.get("suggested_filename"),
                    "path": event.get("path"),
                    "failure": event.get("failure", ""),
                    "size_bytes": event.get("size_bytes", 0),
                }
            )
        elif action == "snapshot":
            snapshots.append(
                {
                    "t": event.get("t"),
                    "reason": event.get("reason"),
                    "path": event.get("path"),
                    "page_count": event.get("page_count"),
                    "control_count": event.get("control_count"),
                }
            )
        if event.get("screenshot"):
            screenshots.append(event["screenshot"])

    summary = {
        "browser_event_count": len(browser_events),
        "url_history": url_history,
        "clicked_elements": clicked_elements,
        "inputs": inputs,
        "downloads": downloads,
        "screenshots": screenshots,
        "snapshots": snapshots,
        "latest_snapshot_file": "browser_snapshot_latest.json",
        "trace_file": "trace.zip" if (session_dir / "trace.zip").exists() else "",
    }
    write_json(session_dir / "browser_summary.json", summary)
    write_playwright_codegen_script(session_dir / "playwright_script.py", browser_events)
    return {
        "browser_summary_file": "browser_summary.json",
        "playwright_script_file": "playwright_script.py",
        "latest_browser_snapshot_file": "browser_snapshot_latest.json",
        "trace_file": summary["trace_file"],
    }


def write_playwright_codegen_script(path: Path, browser_events: list[dict[str, Any]]) -> None:
    lines = [
        "from __future__ import annotations",
        "",
        "from pathlib import Path",
        "from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError",
        "",
        "",
        "def safe_action(label, func):",
        "    try:",
        "        return func()",
        "    except PlaywrightTimeoutError as exc:",
        "        print(f'[timeout] {label}: {exc}')",
        "    except Exception as exc:",
        "        print(f'[error] {label}: {exc}')",
        "",
        "",
        "def main():",
        "    with sync_playwright() as p:",
        "        browser = p.chromium.launch(headless=False)",
        "        context = browser.new_context(accept_downloads=True)",
        "        page = context.new_page()",
    ]

    current_url = ""
    first_url = first_browser_url(browser_events)
    if first_url:
        current_url = first_url
        lines.append(f"        page.goto({py_string(first_url)}, wait_until='domcontentloaded')")

    for event in browser_events:
        action = event.get("action")
        t = event.get("t", "")
        if action == "url_changed":
            url = str(event.get("to_url") or "")
            if url and url != current_url and not url.startswith("about:"):
                lines.append(f"        # t={t} URL changed to {url}")
                current_url = url
            continue
        if action == "frame_navigated":
            if not event.get("is_main"):
                lines.append(f"        # t={t} iframe navigated: {event.get('url', '')}")
            continue
        if action == "click":
            selector = str(event.get("selector") or "")
            text = truncate(str(event.get("element_text") or ""), 80)
            role = str(event.get("element_role") or "")
            if selector:
                lines.append(f"        # t={t} click role={role!r} text={text!r}")
                lines.append(
                    f"        safe_action('click {selector}', lambda: page.locator({py_string(selector)}).click(timeout=10000))"
                )
            else:
                lines.append(f"        # t={t} click had no selector; text={text!r}")
            continue
        if action in {"input", "change"}:
            selector = str(event.get("selector") or "")
            element = event.get("element") or {}
            value = str(element.get("value_preview") or "")
            input_type = str(element.get("type") or "")
            if selector and value and value != "[password masked]" and input_type not in {"checkbox", "radio"}:
                lines.append(f"        # t={t} {action} selector={selector!r}")
                lines.append(
                    f"        safe_action('fill {selector}', lambda: page.locator({py_string(selector)}).fill({py_string(value)}, timeout=10000))"
                )
            elif selector and input_type in {"checkbox", "radio"}:
                checked = bool(element.get("checked"))
                method = "check" if checked else "uncheck"
                lines.append(f"        # t={t} {action} selector={selector!r}")
                lines.append(
                    f"        safe_action('{method} {selector}', lambda: page.locator({py_string(selector)}).{method}(timeout=10000))"
                )
            else:
                lines.append(f"        # t={t} {action} skipped; selector={selector!r} value={value!r}")
            continue
        if action == "download":
            suggested = str(event.get("suggested_filename") or "")
            lines.append(
                f"        # t={t} download observed: {suggested!r} from {event.get('download_url', '')}"
            )

    lines.extend(
        [
            "        print('Replay script finished. Review browser_summary.json and trace.zip for context.')",
            "        context.close()",
            "        browser.close()",
            "",
            "",
            "if __name__ == '__main__':",
            "    main()",
            "",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def first_browser_url(browser_events: list[dict[str, Any]]) -> str:
    for event in browser_events:
        if event.get("action") == "url_changed":
            url = str(event.get("to_url") or "")
            if url and not url.startswith("about:"):
                return url
        url = str(event.get("url") or "")
        if url and not url.startswith("about:"):
            return url
    return ""


def py_string(value: str) -> str:
    return json.dumps(str(value), ensure_ascii=False)


def escape_md(text: str) -> str:
    return text.replace("|", "\\|").replace("\n", " ")


def truncate(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)] + "..."


def write_replay_script(path: Path) -> None:
    script = r'''from __future__ import annotations

import argparse
import ctypes
import json
import time
from pathlib import Path

user32 = ctypes.WinDLL("user32", use_last_error=True)

MOUSE_FLAGS = {
    ("button_down", "left"): 0x0002,
    ("button_up", "left"): 0x0004,
    ("button_down", "right"): 0x0008,
    ("button_up", "right"): 0x0010,
    ("button_down", "middle"): 0x0020,
    ("button_up", "middle"): 0x0040,
}
MOUSEEVENTF_WHEEL = 0x0800
MOUSEEVENTF_HWHEEL = 0x01000
KEYEVENTF_KEYUP = 0x0002


def read_events(path: Path):
    with path.open("r", encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if line:
                yield json.loads(line)


def replay(events_path: Path, speed: float, countdown: int):
    print("Replay starts in", countdown, "seconds.")
    print("Move to the same monitor/layout used during recording.")
    for remaining in range(countdown, 0, -1):
        print(remaining)
        time.sleep(1)

    last_t = 0.0
    for event in read_events(events_path):
        event_type = event.get("type")
        if event_type not in {"mouse", "keyboard"}:
            continue

        t = float(event.get("t", 0.0))
        delay = max(0.0, (t - last_t) / speed)
        if delay:
            time.sleep(delay)
        last_t = t

        if event_type == "mouse":
            do_mouse(event)
        elif event_type == "keyboard":
            do_keyboard(event)


def do_mouse(event):
    action = event.get("action")
    x = int(event.get("x", 0))
    y = int(event.get("y", 0))
    user32.SetCursorPos(x, y)

    if action == "move":
        return
    if action == "wheel":
        user32.mouse_event(MOUSEEVENTF_WHEEL, 0, 0, int(event.get("wheel_delta", 0)), 0)
        return
    if action == "hwheel":
        user32.mouse_event(MOUSEEVENTF_HWHEEL, 0, 0, int(event.get("wheel_delta", 0)), 0)
        return

    flag = MOUSE_FLAGS.get((action, event.get("button")))
    if flag:
        user32.mouse_event(flag, 0, 0, 0, 0)


def do_keyboard(event):
    vk = int(event.get("vk", 0))
    scan = int(event.get("scan_code", 0))
    if not vk:
        return
    flags = KEYEVENTF_KEYUP if event.get("action") == "key_up" else 0
    user32.keybd_event(vk, scan, flags, 0)


def main():
    parser = argparse.ArgumentParser(description="Replay a work_recorder input log.")
    parser.add_argument("events", nargs="?", default="events.jsonl")
    parser.add_argument("--speed", type=float, default=1.0, help="2.0 is twice as fast.")
    parser.add_argument("--countdown", type=int, default=5)
    args = parser.parse_args()
    replay(Path(args.events), max(args.speed, 0.1), max(args.countdown, 0))


if __name__ == "__main__":
    main()
'''
    path.write_text(script, encoding="utf-8")


def write_session_markdown(session_dir: Path, metadata: dict[str, Any], summary: dict[str, Any]) -> None:
    windows = summary.get("windows", [])
    window_lines = []
    for item in windows[:15]:
        title = (item.get("title") or "").replace("|", "\\|").strip()
        proc = (item.get("process_path") or "").replace("|", "\\|").strip()
        window_lines.append(f"| {item.get('t')} | {title} | {proc} |")
    if not window_lines:
        window_lines.append("| - | - | - |")

    video_name = metadata.get("video_file")
    video_file_line = f"- `{video_name}`: optional screen recording" if video_name else ""
    video_summary = f"`{video_name}`" if video_name else "`disabled - script only`"
    evidence_files = (
        f"{video_name}, action_script.md, actions.jsonl, events.jsonl, session.md"
        if video_name
        else "action_script.md, actions.jsonl, events.jsonl, session.md"
    )
    file_lines = "\n".join(
        line
        for line in [
            video_file_line,
            "- `action_script.md`: condensed human-readable workflow script",
            "- `actions.jsonl`: condensed machine-readable workflow timeline",
            "- `events.jsonl`: raw timeline of mouse, keyboard, focused-window, and diagnostic events",
            "- `events.json`: metadata plus the same events in one JSON document",
            "- `replay.py`: coordinate-based replay script for the same PC layout",
            "- `session.md`: this summary",
        ]
        if line
    )
    md = f"""# Work Recording Session

Created: {metadata.get("created_at")}

## Files

{file_lines}

## Summary

- Duration: {summary.get("duration_seconds")} seconds
- Stop hotkey: `{metadata.get("stop_hotkey")}`
- Video: {video_summary}
- Virtual screen: `{metadata.get("virtual_screen")}`
- Event counts: `{summary.get("event_counts")}`

## Focused Windows

| Time | Window title | Process |
| ---: | --- | --- |
{chr(10).join(window_lines)}

## How To Replay

Use replay only on the same monitor layout, resolution, app layout, and data state.

```powershell
python replay.py
```

To replay faster:

```powershell
python replay.py --speed 2
```

## How To Ask Codex To Make A Skill

Give Codex this whole session folder and ask:

```text
이 녹화 폴더를 분석해서 같은 업무를 자동화하는 Codex Skill을 만들어줘.
{evidence_files}를 근거로 작업 순서를 추출하고,
브라우저/엑셀의 의미 있는 단계, 입력값, 예외 상황, 결과물 검증 방법을 SKILL.md에 정리해줘.
좌표 재현이 아니라 사람이 이해할 수 있는 업무 절차와 자동화 가능한 스크립트 구조로 만들어줘.
```

## Notes

- This recorder saves raw input events. It is useful evidence for creating a skill, but a finished skill should prefer semantic automation such as Playwright for browsers and Excel APIs for spreadsheets.
- Avoid recording passwords, personal data, customer data, or secrets unless you are allowed to store and share them.
- Coordinate replay is fragile if windows move, monitors change, zoom changes, or the target data is different.
"""
    (session_dir / "session.md").write_text(md, encoding="utf-8")


def write_session_markdown(session_dir: Path, metadata: dict[str, Any], summary: dict[str, Any]) -> None:
    windows = summary.get("windows", [])
    window_lines = []
    for item in windows[:15]:
        title = escape_md((item.get("title") or "").strip())
        proc = escape_md((item.get("process_path") or "").strip())
        window_lines.append(f"| {item.get('t')} | {title} | {proc} |")
    if not window_lines:
        window_lines.append("| - | - | - |")

    url_lines = []
    for item in summary.get("urls", [])[:20]:
        url_lines.append(
            f"| {item.get('t')} | {escape_md(str(item.get('action') or ''))} | "
            f"{escape_md(str(item.get('url') or ''))} |"
        )
    if not url_lines:
        url_lines.append("| - | - | - |")

    download_lines = []
    for item in summary.get("downloads", [])[:20]:
        download_lines.append(
            f"| {item.get('t')} | {escape_md(str(item.get('suggested_filename') or ''))} | "
            f"{escape_md(str(item.get('path') or ''))} | {escape_md(str(item.get('failure') or ''))} |"
        )
    if not download_lines:
        download_lines.append("| - | - | - |")

    video_name = metadata.get("video_file")
    video_file_line = f"- `{video_name}`: optional screen recording" if video_name else ""
    video_summary = f"`{video_name}`" if video_name else "`disabled - script only`"
    browser_enabled = bool(metadata.get("browser_enabled"))
    browser_artifacts = metadata.get("browser_artifacts") or {}
    browser_lines = []
    if browser_enabled:
        browser_lines = [
            "- `browser_summary.json`: URL changes, clicked element text/role/selector, inputs, downloads, screenshots",
            "- `browser_snapshot_latest.json`: latest iframe tree and button/link/input inventory",
            "- `browser_snapshots/`: timestamped iframe/control snapshots",
            "- `screenshots/`: start/final/click screenshots",
            "- `downloads/`: files captured from browser download events",
            "- `playwright_script.py`: generated Playwright replay/codegen draft",
            "- `trace.zip`: Playwright trace with screenshots and DOM snapshots",
        ]
    file_lines = "\n".join(
        line
        for line in [
            video_file_line,
            "- `action_script.md`: condensed human-readable workflow script",
            "- `actions.jsonl`: condensed machine-readable workflow timeline",
            "- `events.jsonl`: raw timeline of mouse, keyboard, focused-window, browser, and diagnostic events",
            "- `events.json`: metadata plus the same events in one JSON document",
            "- `replay.py`: coordinate-based replay script for the same PC layout",
            *browser_lines,
            "- `session.md`: this summary",
        ]
        if line
    )
    evidence_files = ", ".join(
        item
        for item in [
            "action_script.md",
            "actions.jsonl",
            "events.jsonl",
            "events.json",
            "session.md",
            browser_artifacts.get("browser_summary_file", ""),
            browser_artifacts.get("latest_browser_snapshot_file", ""),
            browser_artifacts.get("playwright_script_file", ""),
            browser_artifacts.get("trace_file", ""),
            video_name or "",
        ]
        if item
    )
    md = f"""# Work Recording Session

Created: {metadata.get("created_at")}

## Files

{file_lines}

## Summary

- Duration: {summary.get("duration_seconds")} seconds
- Stop hotkey: `{metadata.get("stop_hotkey")}`
- Video: {video_summary}
- Browser semantic recording: `{browser_enabled}`
- Virtual screen: `{metadata.get("virtual_screen")}`
- Event counts: `{summary.get("event_counts")}`

## Browser URL Changes

| Time | Action | URL |
| ---: | --- | --- |
{chr(10).join(url_lines)}

## Downloads

| Time | Suggested filename | Saved path | Failure |
| ---: | --- | --- | --- |
{chr(10).join(download_lines)}

## Focused Windows

| Time | Window title | Process |
| ---: | --- | --- |
{chr(10).join(window_lines)}

## How To Replay

Coordinate replay only works on the same monitor layout, resolution, app layout, and data state.

```powershell
python replay.py
```

For browser work, start from the generated Playwright draft and refine selectors if needed.

```powershell
python playwright_script.py
```

## How To Ask Codex To Make A Skill

Give Codex this whole session folder and ask:

```text
이 녹화 폴더를 분석해서 같은 업무를 자동화하는 Codex Skill 또는 에이전트를 만들어줘.
{evidence_files}를 근거로 작업 순서를 추출하고,
클릭 요소의 text/role/selector, URL 변화, iframe 구조, 버튼/link/input 목록,
다운로드 이벤트, screenshot, Playwright trace와 playwright_script.py를 함께 참고해줘.
좌표 재현이 아니라 사람이 이해할 수 있는 업무 절차와 Playwright/파일 처리 기반 자동화 구조로 정리해줘.
```

## Notes

- Browser semantic details are captured only inside the Playwright-managed browser window opened by this recorder.
- Password fields are masked, but ordinary text inputs are recorded. Do not record secrets, customer data, or personal data unless you are allowed to store and share them.
- Coordinate replay is fragile if windows move, monitors change, zoom changes, or the target data is different.
"""
    (session_dir / "session.md").write_text(md, encoding="utf-8")


def run_record(args: argparse.Namespace) -> int:
    ensure_windows()
    out_base = Path(args.out_dir).expanduser().resolve()
    session_dir = create_session_dir(out_base, args.name)
    events_path = session_dir / "events.jsonl"
    events_q: "queue.Queue[dict[str, Any] | None]" = queue.Queue()
    stop_event = threading.Event()
    started_at = time.perf_counter()
    created_at = now_iso()
    stop_hotkey = parse_hotkey(args.stop_hotkey)

    def emit(event: dict[str, Any]) -> None:
        events_q.put(event)

    metadata: dict[str, Any] = {
        "schema_version": RECORD_SCHEMA_VERSION,
        "created_at": created_at,
        "session_dir": str(session_dir),
        "stop_hotkey": args.stop_hotkey,
        "video_enabled": not args.no_video,
        "fps": args.fps,
        "move_sample_ms": args.move_sample_ms,
        "browser_enabled": bool(args.browser),
        "browser_name": args.browser_name,
        "browser_start_url": args.start_url,
        "browser_trace_enabled": bool(args.browser_trace),
        "browser_screenshots_enabled": bool(args.browser_screenshots),
        "browser_inventory_interval": args.browser_inventory_interval,
        "virtual_screen": get_virtual_screen(),
    }

    write_replay_script(session_dir / "replay.py")
    writer = JsonlEventWriter(events_path, events_q)
    writer.start()

    emit(
        {
            "type": "session",
            "action": "started",
            "t": 0,
            "wall_time": created_at,
            "schema_version": RECORD_SCHEMA_VERSION,
            "stop_hotkey": args.stop_hotkey,
        }
    )

    hooks = InputHookRecorder(
        stop_event=stop_event,
        emit=emit,
        started_at=started_at,
        stop_hotkey=stop_hotkey,
        move_sample_ms=args.move_sample_ms,
    )
    windows = WindowMonitor(stop_event, emit, started_at)
    video = None if args.no_video else ScreenRecorder(stop_event, session_dir, args.fps, emit, started_at)
    browser = (
        BrowserSemanticRecorder(
            stop_event=stop_event,
            session_dir=session_dir,
            emit=emit,
            started_at=started_at,
            browser_name=args.browser_name,
            start_url=args.start_url,
            headless=args.browser_headless,
            trace_enabled=args.browser_trace,
            screenshots_enabled=args.browser_screenshots,
            inventory_interval=args.browser_inventory_interval,
        )
        if args.browser
        else None
    )

    def request_stop(signum=None, frame=None) -> None:
        emit(
            {
                "type": "control",
                "action": "signal_stop",
                "t": round(time.perf_counter() - started_at, 6),
                "signal": signum,
            }
        )
        stop_event.set()

    signal.signal(signal.SIGINT, request_stop)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, request_stop)

    hooks.start()
    hooks.ready.wait(5)
    if hooks.error:
        print("Input hook failed. See events.jsonl for details.")
        stop_event.set()

    windows.start()
    if video is not None:
        video.start()
    if browser is not None:
        browser.start()

    if args.duration and args.duration > 0:
        def auto_stop() -> None:
            if not stop_event.wait(args.duration):
                emit(
                    {
                        "type": "control",
                        "action": "duration_stop",
                        "t": round(time.perf_counter() - started_at, 6),
                        "duration": args.duration,
                    }
                )
                stop_event.set()

        threading.Thread(target=auto_stop, daemon=True).start()

    print()
    print("Recording started.")
    modes = ["script/events"]
    if not args.no_video:
        modes.append("screen video")
    if args.browser:
        modes.append("browser semantic")
    print("Mode:", " + ".join(modes))
    print("Session folder:", session_dir)
    print(f"Stop with {args.stop_hotkey.upper()} or Ctrl+C in this console.")
    if args.browser:
        print("Do browser work in the Playwright window that this recorder opens.")
    print("Do your browser or Excel work now.")
    print()

    while not stop_event.is_set():
        time.sleep(0.2)

    hooks.join(timeout=2)
    windows.join(timeout=2)
    if video is not None:
        video.join(timeout=5)
    if browser is not None:
        if browser.is_alive():
            print("Stopping browser semantic recorder. This can take a little while when trace/video artifacts are being finalized.")
        shutdown_started = time.perf_counter()
        while browser.is_alive():
            browser.join(timeout=BROWSER_SHUTDOWN_CHECK_SECONDS)
            if browser.is_alive() and time.perf_counter() - shutdown_started >= BROWSER_SHUTDOWN_MAX_SECONDS:
                browser.shutdown_timed_out = True
                browser.error = browser.error or (
                    f"Browser semantic recorder did not stop within {BROWSER_SHUTDOWN_MAX_SECONDS:.0f} seconds. "
                    "Screen video and raw input events were still saved."
                )
                emit(
                    {
                        "type": "browser",
                        "action": "shutdown_timeout",
                        "t": round(time.perf_counter() - started_at, 6),
                        "wall_time": now_iso(),
                        "timeout_seconds": BROWSER_SHUTDOWN_MAX_SECONDS,
                    }
                )
                terminate_child_processes(os.getpid())
                break

    emit(
        {
            "type": "session",
            "action": "stopped",
            "t": round(time.perf_counter() - started_at, 6),
            "wall_time": now_iso(),
        }
    )
    events_q.put(None)
    writer.join(timeout=5)

    events = read_jsonl(events_path)
    summary = summarize_events(events)
    actions = build_action_timeline(events)
    metadata["action_count"] = len(actions)
    if video is not None and video.video_path:
        metadata["video_file"] = video.video_path.name
        metadata["video_frames"] = video.frame_count
    if writer.error:
        metadata["writer_error"] = writer.error
    if video is not None and video.error:
        metadata["video_error"] = video.error
    if hooks.error:
        metadata["input_hook_error"] = hooks.error
    if browser is not None:
        if browser.error:
            metadata["browser_error"] = browser.error
        if browser.trace_file:
            metadata["browser_trace_file"] = browser.trace_file

    write_action_files(session_dir, actions)
    browser_artifacts = write_browser_artifacts(session_dir, events)
    if browser_artifacts:
        metadata["browser_artifacts"] = browser_artifacts
    write_json(
        session_dir / "events.json",
        {
            "metadata": metadata,
            "summary": summary,
            "actions_file": "actions.jsonl",
            "action_script_file": "action_script.md",
            "browser_summary_file": browser_artifacts.get("browser_summary_file", ""),
            "playwright_script_file": browser_artifacts.get("playwright_script_file", ""),
            "events": events,
        },
    )
    write_session_markdown(session_dir, metadata, summary)

    print("Recording saved.")
    print("Session folder:", session_dir)
    print("Duration:", summary["duration_seconds"], "seconds")
    print("Events:", summary["event_counts"])
    print("Condensed actions:", len(actions))
    browser_failed = bool(browser and browser.error and not browser.shutdown_timed_out)
    return 0 if not hooks.error and not browser_failed else 2


def run_replay(args: argparse.Namespace) -> int:
    session = Path(args.session).expanduser().resolve()
    events = session / "events.jsonl" if session.is_dir() else session
    replay_script = session / "replay.py" if session.is_dir() else session.parent / "replay.py"
    if not events.exists():
        print("Cannot find events.jsonl:", events)
        return 1
    if not replay_script.exists():
        write_replay_script(replay_script)
    print("Replay script:", replay_script)
    print("Run this command from PowerShell:")
    print(f'python "{replay_script}" "{events}" --speed {args.speed}')
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Record screen video plus mouse/keyboard/window events for skill creation."
    )
    sub = parser.add_subparsers(dest="command")

    record = sub.add_parser("record", help="Start recording a work session.")
    record.add_argument(
        "--out-dir",
        default=str((Path(__file__).resolve().parents[2] / "recordings")),
        help="Base folder where timestamped session folders are created.",
    )
    record.add_argument("--name", default="work_recording", help="Session name suffix.")
    record.add_argument("--fps", type=float, default=8.0, help="Screen recording FPS when --with-video is used.")
    record.add_argument(
        "--move-sample-ms",
        type=int,
        default=70,
        help="Mouse move sampling interval. Clicks and keyboard events are always captured.",
    )
    record.add_argument("--stop-hotkey", default=DEFAULT_STOP_HOTKEY)
    record.add_argument("--duration", type=float, default=0.0, help="Auto-stop after N seconds.")
    browser_group = record.add_mutually_exclusive_group()
    browser_group.add_argument(
        "--browser",
        dest="browser",
        action="store_true",
        help="Launch a Playwright-managed browser and record URL/DOM/iframe/download/screenshot/trace details.",
    )
    browser_group.add_argument(
        "--no-browser",
        dest="browser",
        action="store_false",
        help="Disable Playwright browser semantic recording.",
    )
    record.add_argument("--start-url", default=DEFAULT_BROWSER_START_URL, help="Initial URL for --browser.")
    record.add_argument(
        "--browser-name",
        choices=("chromium", "firefox", "webkit"),
        default="chromium",
        help="Playwright browser engine for --browser.",
    )
    record.add_argument("--browser-headless", action="store_true", help="Run the Playwright browser headless.")
    record.add_argument(
        "--browser-inventory-interval",
        type=float,
        default=2.0,
        help="Seconds between iframe/control inventory snapshots.",
    )
    record.add_argument(
        "--no-browser-trace",
        dest="browser_trace",
        action="store_false",
        help="Disable trace.zip generation for --browser.",
    )
    record.add_argument(
        "--no-browser-screenshots",
        dest="browser_screenshots",
        action="store_false",
        help="Disable start/final/click screenshots for --browser.",
    )
    video_group = record.add_mutually_exclusive_group()
    video_group.add_argument(
        "--no-video",
        dest="no_video",
        action="store_true",
        help="Record script/events only. This is the default.",
    )
    video_group.add_argument(
        "--with-video",
        dest="no_video",
        action="store_false",
        help="Also record screen video. This creates much larger files.",
    )
    record.set_defaults(func=run_record, no_video=True, browser=False, browser_trace=True, browser_screenshots=True)

    replay = sub.add_parser("replay", help="Print the command for replaying a session.")
    replay.add_argument("session", help="Session folder or events.jsonl path.")
    replay.add_argument("--speed", type=float, default=1.0)
    replay.set_defaults(func=run_replay)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "func"):
        args = parser.parse_args(["record", *(argv or [])])
    try:
        return args.func(args)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print("Error:", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
