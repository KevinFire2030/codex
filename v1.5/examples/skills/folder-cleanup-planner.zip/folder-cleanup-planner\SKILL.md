﻿---
name: folder-cleanup-planner
description: Use this skill when the user wants a safe file cleanup plan before moving or deleting files. Always inspect first, propose a plan, and wait for explicit approval before changing files.
---

# Folder Cleanup Planner

Use this skill to help users organize a folder safely.

## Rules

- Do not move, rename, or delete files until the user explicitly approves.
- Start by summarizing the current folder structure.
- Group files by type such as documents, spreadsheets, images, archives, installers, and source files.
- Treat duplicate files as review candidates, not deletion targets.
- Ask before touching project files, hidden files, `.env`, Git folders, or generated outputs.
- Keep original files recoverable.

## Response Format

1. Current folder summary
2. Recommended folder structure
3. Move candidates
4. Duplicate review candidates
5. Questions to ask before execution

## Trigger Examples

- 폴더 정리 계획 세워줘
- 이 폴더 파일을 종류별로 정리하고 싶어
- 중복 파일 후보만 찾아줘. 삭제는 하지 마
