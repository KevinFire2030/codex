﻿# folder-cleanup-planner

This is a sample Codex skill for training.

It helps create a safe file cleanup plan before any files are moved or deleted.
Do not put real secrets, customer files, or internal documents in this sample package.
