@echo off
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found.
  echo Install Python 3.10 or newer, then run this file again.
  pause
  exit /b 1
)

if not exist "recordings" mkdir "recordings"

python -c "import playwright" >nul 2>nul
if errorlevel 1 (
  echo Playwright is required for browser semantic recording.
  echo Run install_browser_dependencies.bat first, then run this file again.
  pause
  exit /b 1
)

python work_recorder.py record --out-dir "%~dp0recordings" --name work_recording --with-video --browser --start-url "about:blank"
pause
